package com.easylearning;

public class Student {
	
	int rollno;
	String name;
	char gender;
	//static String schoolName = "SJS";
	
    static {
    	System.out.println("static block called!!");
    }

}
