
insert into student(rollno, name, gender) values (1001,'Jack','M');
insert into student(rollno, name, gender) values (1002,'Jackson','M');
insert into student(rollno, name, gender) values (1003,'Jessica','F');

commit;