package com.easylearning;

public class Test1 {
	
	public static void main(String[] args) throws Exception{
		Class.forName("com.easylearning.Student");
	}

}
