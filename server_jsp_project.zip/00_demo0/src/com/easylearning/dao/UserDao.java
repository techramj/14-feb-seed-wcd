package com.easylearning.dao;

import java.sql.Connection;

import com.easylearning.ConnectionUtil;

public class UserDao {
	
	private Connection connection = ConnectionUtil.getConnection();


}
