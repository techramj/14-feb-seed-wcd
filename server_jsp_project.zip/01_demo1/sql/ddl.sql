create table student(rollno number primary key,
name varchar2(20) not null,
gender char 
);